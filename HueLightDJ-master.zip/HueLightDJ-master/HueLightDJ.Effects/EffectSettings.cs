using HueApi.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace HueLightDJ.Effects
{
  public static class EffectSettings
  {
    public static HuePosition LocationCenter { get; set; } = new HuePosition();

  }
}
